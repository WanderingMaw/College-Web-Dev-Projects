// immediate "Hello World" alert popup
alert(`Hello World!`);

// prompt user for name, store it, then place it in the greeting div in the HTML
let name = prompt(`Please enter your name:`);
document.querySelector("#greeting").textContent = `Hello, ${name}. Nice to meet you.`;

// prompt user for monetary amount, and tax rate, then calculate that amount of money with that tax rate applied to it
let moneyAmount = parseInt(prompt(`Please enter the amount of money:`));
let taxRate = parseInt(prompt(`Please enter the tax rate:`));
let taxAmount = moneyAmount * (taxRate/100);
let totalAmount = taxAmount + moneyAmount;
totalAmount = parseFloat(totalAmount);
totalAmount = totalAmount.toFixed(2);

// display the monetary amount, tax rate, and calculated total in the table
document.querySelector("#amount").textContent = `$${moneyAmount}`;
document.querySelector("#tax-rate").textContent = `${taxRate}%`;
document.querySelector("#total").textContent = `$${totalAmount}`;