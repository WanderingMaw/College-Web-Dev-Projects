// VARIABLE DECLARATION

//middle number variables
let num1 = parseInt(prompt(`Please enter the first number:`));
let num2 = parseInt(prompt(`Please enter the second number:`));
let num3 = parseInt(prompt(`Please enter the third number:`));

let midNum;


// grade calculator variables
let percentage = parseInt(prompt(`Please enter the percentage for the grade:`));


//saanich fog variables
const saanichArea = 103.8;
const fogIncreaseRate = 0.04;
let fogSize = 3;
let minutes = 0;
let halfway;
let timHortons = saanichArea / 2;
let pastHalf = false;

// MIDDLE NUMBER
if ((num1 > num2 && num1 < num3) || (num1 > num3 && num1 < num2)) {
    midNum = num1;
} else if ((num2 > num1 && num2 < num3) || (num2 > num3 && num2 < num1)) {
    midNum = num2;
} else {
    midNum = num3;
}

document.querySelector("#mid-num").textContent = `The middle number of (${num1}, ${num2}, ${num3}) is: ${midNum}`;
if (midNum % 2 === 0) {
    document.querySelector("#mid-num").classList.add("alert-light");
} else {
    document.querySelector("#mid-num").classList.add("alert-danger");
}

// GRADE CALCULATOR
while (percentage > 100 || percentage < 0) {
    percentage = parseInt(prompt(`Incorrect - not between 0-100: `));
}

// switch case which will stop at the highest value that matches, and apply those effects
switch (true) {
    case (percentage > 90):
        document.querySelector("#display-grade").innerHTML = `The letter grade for ${percentage} is: <span class="fw-bold">A</span>`;
        document.querySelector("#display-grade").classList.add("alert-success")
        break;
    case (percentage > 80):
        document.querySelector("#display-grade").innerHTML = `The letter grade for ${percentage} is: <span class="fw-bold">B</span>`;
        document.querySelector("#display-grade").classList.add("alert-primary")
        break;
    case (percentage > 65):
        document.querySelector("#display-grade").innerHTML = `The letter grade for ${percentage} is: <span class="fw-bold">C</span>`;
        document.querySelector("#display-grade").classList.add("alert-warning")
        break;
    case (percentage > 50):
        document.querySelector("#display-grade").innerHTML = `The letter grade for ${percentage} is: <span class="fw-bold">D</span>`;
        document.querySelector("#display-grade").classList.add("alert-dark")
        break;
    default:
        document.querySelector("#display-grade").innerHTML = `The letter grade for ${percentage} is: <span class="fw-bold">F</span>`;
        document.querySelector("#display-grade").classList.add("alert-danger")
        break;
}

// ITERATION-1
for (let i = 1; i < 11; i++) { // loop through each row of the triangle
    if (i < 6) { // switch the loop past the halfway point to make the amount of "#" decrease
        for (let j = 0; j < i; j++) { // draw the first half of the triangle in increasing increments
            document.querySelector("#draw-triangle").innerHTML += `# `; 
        }
    } else {
        for (let j = 10; j > i; j--) { // drawt the second half of the triangle in decreasing increments
            document.querySelector("#draw-triangle").innerHTML += `# `; 
        }
    }
    document.querySelector("#draw-triangle").innerHTML += `<br>`;
}

// The Fog That Ate Saanich
while (fogSize < saanichArea) {
    minutes ++;
    fogSize += fogSize * fogIncreaseRate; // increases fogSize by 4%
    if (fogSize >= timHortons && pastHalf == false) { // check if the fog has covered half of Saanich, and if it has, assign a value to halfway then lock this check from happening again with a boolean
        halfway = minutes;
        pastHalf = true;
    }
}

document.querySelector("#saanich-fog").innerHTML += `Minutes until Saanich is enveloped: ${minutes}`;
document.querySelector("#saanich-fog").innerHTML += `<br>Minutes until fog overcomes Tim Horton's in Royal Oak: ${halfway}`;