// LETTER COUNT PART 1.1
// function with string and character arguments that returns the number of times that character is in the given string
const letterCount = (string, char) => {
    let count = 0; // number of times letter is in string
    
    for (let letter of string) { // loop through the string to find each letter. using "let ... of ..." to get the letter directly
        if (letter == char) { // if the current letter of the string is the same as the character passed to the function, increase the count by 1
            count++;
        }
    }

    return count;
}

// test "This is a string" with char 'i'. 
let string = "This is a string";
let char = 'i';

document.querySelector("#letter-count").innerHTML += `<p><span class="fw-bold">The string is: </span>${string}</p>`; // The string is: This is a string
document.querySelector("#letter-count").innerHTML += `<p>The letter '${char}' appears ${letterCount(string, char)} time(s).</p>`; // "the letter 'i' appears 3 time(s)."

// test "Foo Bar" with char 'o'.
string = "Foo Bar";
char = 'o';

document.querySelector("#letter-count").innerHTML += `<p><span class="fw-bold">The string is: </span>${string}</p>`; // The string is: Foo Bar
document.querySelector("#letter-count").innerHTML += `<p>The letter '${char}' appears ${letterCount(string, char)} time(s).</p>`; // the letter 'o' appears 2 time(s).

// test "Hello World!" with char 'd'
string = "Hello World!";
char = 'd';

document.querySelector("#letter-count").innerHTML += `<p><span class="fw-bold">The string is: </span>${string}</p>`; // The string is: Hello World!
document.querySelector("#letter-count").innerHTML += `<p>The letter '${char}' appears ${letterCount(string, char)} time(s).</p>`; // The letter 'd' appears 1 time(s)

// PART 1.2
let labDay = new Date();

// Date object function examples using default Date() constructor
console.log(`labDay is ${labDay}`); // "labDay is weekDay month date year 00:00:00 GMT-0800 (Pacific Standard Time)"
console.log(labDay.toDateString()); // "weekDay month date year"
console.log(labDay.toTimeString()); // 00:00:00 GMT-0800 (Pacific Standard Time)
console.log(`labDay as UTC is ${labDay.getTime()}`); // "labDay as UTC is 1738097998065" (milliseconds since midnight January 1, 1970)
console.log(labDay.getDate() + " / " + labDay.getMonth() + " / " + labDay.getFullYear()); // "28 / 0 / 2025" (dd/mm/yyyy, month is 0 based... for arrays?)
console.log(labDay.getHours() + " : " + labDay.getMinutes()); // 13 : 5 (24 hour clock, no 0 before minutes)

console.log(`-------------------------------------------------`);

// adding the change here instead of changing it so I can keep all my nice comments and examples :)
// Date examples using March 1, 2022
labDay = new Date(2022, 2, 1);

console.log(`labDay is ${labDay}`); // "labDay is Tue Mar 01 2022 00:00:00 GMT-0800 (Pacific Standard Time)"
console.log(labDay.toDateString()); // "Tue Mar 01 2022"
console.log(labDay.toTimeString()); // 00:00:00 GMT-0800 (Pacific Standard Time)
console.log(`labDay as UTC is ${labDay.getTime()}`); // "labDay as UTC is 1646121600000" (milliseconds since midnight January 1, 1970)
console.log(labDay.getDate() + " / " + labDay.getMonth() + " / " + labDay.getFullYear()); // "1 / 2 / 2022" (dd/mm/yyyy, month is 0 based... for arrays?)
console.log(labDay.getHours() + " : " + labDay.getMinutes()); // 0 : 0 (24 hour clock, no 0 before minutes)

// Date examples using Date.now()
let now = Date.now(); // same as (new Date()).getTime()

console.log(now); //"1738098703606" (UTC format)

// Date examples using a number bigger than 11 as the month to scale the date forward 
let errorDate = new Date(2016, 33, 1); 

console.log(errorDate); // Mon Oct 01 2018 00:00:00 GMT-0700 (Pacific Daylight Time)

// Date examples using a Date given an invalid string
let invalidDate = new Date("Funuary 3, 2018");

console.log(invalidDate); // "Invalid Date"

// Date examples of different format options
let options = { weekday: 'long' , year: 'numeric', month: 'long', day: 'numeric' };

console.log(labDay.toLocaleString('de-DE', options)); // switches to German, then applies the settings given in the options object: "Dienstag, 1. März 2022"

// doing weird millisecond math to change dates
let msDay = 1000 * 60 * 60 * 24; // milliseconds -> seconds -> minutes -> hours
let msLabDay = Date.now();
labDay = new Date(msLabDay + msDay); // makes the date tomorrow

console.log(labDay); // Wed Jan 29 2025 13:21:50 GMT-0800 (Pacific Standard Time)

// ACTUAL EXERCISE: PAYROLL
let workHours = 7.5;
let wage = parseFloat(prompt("Please enter the wage for the employee:"));
wage = wage.toFixed(2);
const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

// test variables
let year = 2025;
let month = 1;

// function to get the number of days in a month (Provided by Brandon)
function daysInMonth (year, month) { // Use 1 for Jan, 2 for Feb, etc.
    return new Date(year, month, 0).getDate();
}

// function to find number of weekdays in month
const numOfWeekdays = (year, month, totalDays) => {
    let weekdays = 0;

    // loop through each day in the month
    for (let day = 0; day < totalDays; day++) {
        date = new Date(year, month-1, day); // find day in the month. (-1 to account for the month being 1 higher for the other function)
        let dayOfWeek = date.getDay(); // find the day of the week (as number 0-6)
        if (dayOfWeek != 0 && dayOfWeek != 6) { // check if the current day is a weekday, if so, add to weekdays
            weekdays++;
        }
    }

    return weekdays;
}

// function to handle all the data for wage calculation, then display it in HTML
const wageCalculator = (wage, year, month) => {
    // assign number of daysInMonth to variable totalDays
    let totalDays = daysInMonth(year, month);

    // assign number of workdays in the month to variable numWeekDays
    let numWeekdays = numOfWeekdays(year, month, totalDays);

    let monthlySalary = wage * workHours * numWeekdays;
    monthlySalary = monthlySalary.toFixed(2); // fix monthlySalary to 2 decimal points

    document.querySelector("#month").innerHTML += months[month-1];
    document.querySelector("#year").innerHTML += year;
    document.querySelector("#weekdays").innerHTML += numWeekdays;
    document.querySelector("#wage").innerHTML += wage;
    document.querySelector("#pay").innerHTML += monthlySalary;
}

wageCalculator(wage, year, month);

// ERROR HANDLING
let calcFutureValue = (principle, rate, years) => {
    if (principle <= 0) {
        throw new Error("Principle value must be greater than zero");
    } else if (rate <= 0) {
        throw new Error("Rate value must be greater than zero");
    } else if (years <= 0) {
        throw new Error("Years value must be greater than 0");
    }

    let monthlyRate = (rate / 12) / 100;
    let months = years * 12;
    let futureValue = 0
    for (let i = 0; i < months; i++) {
        futureValue = (futureValue + principle) * (1 + monthlyRate);
    }

    futureValue = futureValue.toFixed(2);
    return futureValue;
}

let investment = 10;
let annualRate = 4;
let years = 5;

try {
    console.log(calcFutureValue(investment, annualRate, years));
} catch (error) {
    console.log(error);
}

investment = 0;
annualRate = 4;
years = 5;

try {
    console.log(calcFutureValue(investment, annualRate, years));
} catch (error) {
    console.log(error);
}

investment = 10;
annualRate = 0;
years = 5;

try {
    console.log(calcFutureValue(investment, annualRate, years));
} catch (error) {
    console.log(error);
}

investment = 10;
annualRate = 4;
years = 0;

try {
    console.log(calcFutureValue(investment, annualRate, years));
} catch (error) {
    console.log(error);
}

investment = 10;
annualRate = 4;
years = 5;

try {
    document.querySelector("#invest1").textContent += (calcFutureValue(investment, annualRate, years));
} catch (error) {
    document.querySelector("#invest1").textContent += error;
}

investment = 4;
annualRate = 10;
years = 5;

try {
    document.querySelector("#invest2").textContent += (calcFutureValue(investment, annualRate, years));
} catch (error) {
    document.querySelector("#invest2").textContent += error;
}

investment = 5;
annualRate = 4;
years = 0;

try {
    document.querySelector("#invest3").textContent += (calcFutureValue(investment, annualRate, years));
} catch (error) {
    document.querySelector("#invest3").textContent += error;
}